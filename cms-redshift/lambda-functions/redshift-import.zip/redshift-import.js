const Promise = require('bluebird');
const {Pool} = require('pg');



function loadInRedshift(user,host, password,database,port, sql) {
    const pool = new Pool({
	user: user,
	host: host,
	password: password,
	database: database,
	port: port,
    });
    
    return new Promise(function (fulfill, reject) {
        
        console.log("Connecting to " + host);
        pool.connect(function (err, client, done) {
            if (err) {
                console.error("Connection error", err);
                reject(err);
            } else {
                console.log("Executing \n" + sql);
                client.query(sql, function (err, result) {
                    if (err) {
                        console.error("Query error", err);
                        reject(err);
                    } else {
                        var data = result.rows;
                        client.end(function (err) {
                            if (err) {
                                console.error("Close error", err);
                                reject(err);
                            }
                            fulfill(data);
                        });
                    }
                });
            }
        });
    });
}

exports.handler = function(event, context, callback) {
    const user = process.env.USER;
    const host = process.env.HOST;
    const database = process.env.DATABASE;
    const password = process.env.PASSWORD;
    const port = process.env.PORT;
    const sql = process.env.SQL;
    loadInRedshift(user,host, password,database,port, sql).then(callback(null, "OK"));
};