import boto3
import json

# Region
region = 'us-east-1'

# Instances ID
instances = ['i-0eb9a408ec2b491c8']

def lambda_handler(event, context):
    # Stop ec2 instance
    try:
        ec2 = boto3.client('ec2', region_name=region)
        ec2.stop_instances(InstanceIds=instances)
        print('Stopped Instance ID {0}'.format(instances))
        return {
            'statusCode': 200,
            'body': json.dumps('Success')
        }
    except:
        return {
            'statusCode': 400,
            'body': json.dumps('Failed. Check logs')
        }
