import boto3
import json

# Region
region = 'us-east-1'

# Instances ID
instances = ['i-0eb9a408ec2b491c8']

def lambda_handler(event, context):
    # Start ec2 instance
    try:
        ec2 = boto3.client('ec2', region_name=region)
        ec2.start_instances(InstanceIds=instances)
        print('Started Instance ID {0} for processing'.format(instances))
        return {
            'statusCode': 200,
            'body': json.dumps('Success')
        }
    except:
        return {
            'statusCode': 400,
            'body': json.dumps('Failed. Check logs')
        }